
// astroem.js: astronomy utilities compiled to js

var Astroem = (function() {

