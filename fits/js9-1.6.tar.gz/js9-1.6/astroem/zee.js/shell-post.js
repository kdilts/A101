
  return {
    compress: Module['gzcompress'],
    decompress: Module['gzdecompress']
  };
})();

