
// zee.js: zlib compiled to js

var Zee = (function() {

